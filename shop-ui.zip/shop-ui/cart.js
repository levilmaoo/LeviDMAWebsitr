document.addEventListener('DOMContentLoaded', function () {
    // Retrieve cart from local storage
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Reference to cart items container and total price
    const cartItemsContainer = document.getElementById('cart-items');
    const totalPriceElement = document.getElementById('total-price');

    let total = 0;

    // Generate cart items HTML
    cart.forEach((item, index) => {
        const itemElement = document.createElement('div');
        itemElement.classList.add('cart-item');
        itemElement.innerHTML = `
            <span class="cart-item-name">${item.name}</span>
            <span class="cart-item-price">$${item.price}</span>
            <button class="remove-button" onclick="removeFromCart(${index})">Remove</button>
        `;
        cartItemsContainer.appendChild(itemElement);
        total += item.price;
    });

    // Update total price
    totalPriceElement.textContent = total.toFixed(2);

    // Handle checkout button click
    document.getElementById('checkout-button').addEventListener('click', function () {
        // Initialize Stripe
        const stripe = Stripe('your-publishable-key-here'); // Replace with your Stripe public key

        // Create a checkout session
        fetch('/create-checkout-session', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                items: cart,
                total: total
            })
        }).then(response => response.json())
            .then(sessionId => {
                // Redirect to checkout
                return stripe.redirectToCheckout({ sessionId: sessionId });
            }).catch(error => {
                console.error('Error:', error);
            });
    });
});

// Function to remove item from cart
function removeFromCart(index) {
    // Retrieve cart from local storage
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Remove item at the specified index
    cart.splice(index, 1);

    // Save updated cart back to local storage
    localStorage.setItem('cart', JSON.stringify(cart));

    // Reload the cart page to reflect changes
    window.location.reload();
}
