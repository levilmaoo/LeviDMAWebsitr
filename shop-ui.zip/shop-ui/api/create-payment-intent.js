// api/create-payment-intent.js

const stripe = require('stripe')('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'); // Replace with your Stripe secret key
const cors = require('cors');
const express = require('express');
const app = express();

app.use(cors());
app.use(express.json());

app.post('/api/create-payment-intent', async (req, res) => {
    const { paymentMethodId } = req.body;

    try {
        const paymentIntent = await stripe.paymentIntents.create({
            amount: 1000, // Amount in cents (e.g., $10.00)
            currency: 'usd',
            payment_method: paymentMethodId,
            confirmation_method: 'manual',
            confirm: true,
        });

        res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = app;
