// Initialize Stripe
const stripe = Stripe('pk_live_51PpJZNJHRTsXNCx7cXVwb3VkJhtagiBFYU6qHBZRwgk7OGvArB3Z2duzGkVCZJFHW4ydd5w6qU6SsXloia76g77o00rxn5m3bj'); // Replace with your own key
const elements = stripe.elements();
const cardElement = elements.create('card');

cardElement.mount('#card-element');

// Handle form submission
const form = document.getElementById('payment-form');
form.addEventListener('submit', async (event) => {
    event.preventDefault();

    const { paymentMethod, error } = await stripe.createPaymentMethod({
        type: 'card',
        card: cardElement,
    });

    if (error) {
        document.getElementById('error-message').innerText = error.message;
    } else {
        // Send paymentMethod.id to your server to complete payment
        const response = await fetch('/create-payment-intent', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ paymentMethodId: paymentMethod.id }),
        });

        const paymentIntentResponse = await response.json();

        const result = await stripe.confirmCardPayment(paymentIntentResponse.clientSecret);

        if (result.error) {
            document.getElementById('error-message').innerText = result.error.message;
        } else {
            if (result.paymentIntent.status === 'succeeded') {
                window.location.href = '/thank-you.html'; // Redirect after payment
            }
        }
    }
});
